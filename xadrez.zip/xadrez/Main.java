package xadrez;
import xadrez.controle.Jogo;

// Incializa o jogo

public class Main {
    public static void main(String[] args) {

        Jogo jogo = new Jogo();
        jogo.iniciar();

    }
}