




package xadrez.controle;

import xadrez.tabuleiro.Tabuleiro;
import xadrez.peca.Peao;
import xadrez.exceptions.XadrezException;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import java.awt.Font;

public class Jogo {

    private final Tabuleiro tabuleiro;
    private boolean turnoBranco;
    private int tentativasMovimento;

    public Jogo() {
        this.tabuleiro = new Tabuleiro();
        this.turnoBranco = true;
        this.tentativasMovimento = 0;
        inicializarPecas();
    }

    // Posiciona os peões iniciais no tabuleiro
    private void inicializarPecas() {
        for (int coluna = 0; coluna < 8; coluna++) {
            tabuleiro.colocarPeca(new Peao(1, coluna, Peao.Cor.BRANCO), 1, coluna);
        }
        for (int coluna = 0; coluna < 8; coluna++) {
            tabuleiro.colocarPeca(new Peao(6, coluna, Peao.Cor.PRETO), 6, coluna);
        }
    }

    public void iniciar() {
        while (true) {
            exibirTabuleiro();
            tentativasMovimento = 0;

            while (true) {
                tentativasMovimento++;
                try {
                    // Solicita posição de origem ao jogador
                    String origem = solicitarPosicao((turnoBranco ? "Turno: Brancas (♙)" : "Turno: Pretas (♟)")
                            + "\nTentativa: " + tentativasMovimento + "\nDigite a origem (linha,coluna):");

                    if (origem == null) {
                        encerrarJogo();
                        return;
                    }

                    int[] coordenadasOrigem = parsearCoordenadas(origem);
                    int linhaOrigem = coordenadasOrigem[0];
                    int colunaOrigem = coordenadasOrigem[1];

                    // Solicita posição de destino
                    String destino = solicitarPosicao("Digite o destino (linha,coluna):");
                    if (destino == null) {
                        cancelarMovimento();
                        break;
                    }

                    int[] coordenadasDestino = parsearCoordenadas(destino);
                    int linhaDestino = coordenadasDestino[0];
                    int colunaDestino = coordenadasDestino[1];

                    // Valida se a peça escolhida é do jogador correto
                    validarPecaDoTurno(linhaOrigem, colunaOrigem);

                    // Executa o movimento da peça
                    executarMovimento(linhaOrigem, colunaOrigem, linhaDestino, colunaDestino);

                    break;

                } catch (XadrezException e) {
                    exibirErroRegra(e);
                } catch (NumberFormatException e) {
                    exibirErroInput();
                }
            }

            // Alterna o turno
            turnoBranco = !turnoBranco;
        }
    }

    // Exibe caixa de diálogo para entrada de posição
    private String solicitarPosicao(String mensagem) {
        return JOptionPane.showInputDialog(null, mensagem, "Jogo de Xadrez", JOptionPane.QUESTION_MESSAGE);
    }

    // Converte entrada de texto em coordenadas do tabuleiro
    private int[] parsearCoordenadas(String input) throws XadrezException {
        String[] parts = input.split("[,\\s]+");
        if (parts.length != 2) {
            throw new XadrezException(XadrezException.TipoErro.INPUT_INVALIDO);
        }

        int linha = Integer.parseInt(parts[0].trim());
        int coluna = Integer.parseInt(parts[1].trim());
        return new int[]{linha, coluna};
    }

    // Verifica se a peça na posição pertence ao jogador atual
    private void validarPecaDoTurno(int linha, int coluna) throws XadrezException {
        Peao peca = tabuleiro.obterPeca(linha, coluna);

        if (peca == null) {
            throw new XadrezException(XadrezException.TipoErro.POSICAO_VAZIA);
        }
        if ((peca.getCor() == Peao.Cor.BRANCO) != turnoBranco) {
            throw new XadrezException(XadrezException.TipoErro.PECA_ADVERSARIA);
        }
    }

    // Executa o movimento no tabuleiro e exibe mensagem de sucesso
    private void executarMovimento(int linhaOrigem, int colunaOrigem, int linhaDestino, int colunaDestino)
            throws XadrezException {
        tabuleiro.moverPeca(linhaOrigem, colunaOrigem, linhaDestino, colunaDestino);
        JOptionPane.showMessageDialog(null, "Movimento realizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
    }

    // Exibe mensagem de encerramento do jogo
    private void encerrarJogo() {
        JOptionPane.showMessageDialog(null, "Jogo encerrado.");
    }

    // Exibe mensagem de cancelamento de movimento
    private void cancelarMovimento() {
        JOptionPane.showMessageDialog(null, "Movimento cancelado. Recomece o turno.");
    }

    // Exibe mensagem de erro de regra do xadrez
    private void exibirErroRegra(XadrezException e) {
        JOptionPane.showMessageDialog(null, e.getTipoErro().getMensagem(), "Erro de Regra", JOptionPane.ERROR_MESSAGE);
    }

    // Exibe mensagem de erro de entrada inválida
    private void exibirErroInput() {
        JOptionPane.showMessageDialog(null, "Erro: " + XadrezException.TipoErro.INPUT_INVALIDO.getMensagem(), "Erro de Input", JOptionPane.ERROR_MESSAGE);
    }

    // Exibe o tabuleiro em uma caixa de diálogo usando JTextArea
    private void exibirTabuleiro() {
        StringBuilder sb = new StringBuilder();
        sb.append("   0 1 2 3 4 5 6 7 \n");

        for (int linha = 7; linha >= 0; linha--) {
            sb.append(linha).append("  ");

            for (int coluna = 0; coluna < 8; coluna++) {
                Peao p = tabuleiro.obterPeca(linha, coluna);
                sb.append(p == null ? ". " : p.getRepresentacao() + " ");
            }
            sb.append("\n");
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 20));

        JOptionPane.showMessageDialog(null, textArea, "Tabuleiro de Xadrez", JOptionPane.PLAIN_MESSAGE);
    }
}
