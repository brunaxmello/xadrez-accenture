package xadrez.exceptions;

// Exceção personalizada para erros no domínio do xadrez.
// Extende RuntimeException para ser uma exceção não-verificada.

public class XadrezException extends RuntimeException {

	private final TipoErro tipoErro;

	public XadrezException(TipoErro tipoErro) {
		super(tipoErro.getMensagem());
		this.tipoErro = tipoErro;
	}

	public TipoErro getTipoErro() {
		return tipoErro;
	}

	public enum TipoErro {

		// Erros de posição e seleção
		POSICAO_INVALIDA("Posição fora do tabuleiro! Use valores entre 0 e 7 para linha e coluna."),
		POSICAO_VAZIA("Casa vazia! Não há peça nesta posição para mover."),
		PECA_ADVERSARIA("Peça adversária! Esta peça não pertence a você. Não é sua vez para movê-la."),

		// Erros de movimento e destino
		MOVIMENTO_INVALIDO("Movimento inválido! Peões só podem avançar 1 casa (ou 2 na primeira jogada)."),
		PEAO_JA_MOVIMENTADO("Peão já movimentado! Após o primeiro movimento, só é permitido avançar 1 casa."),
		DESTINO_OCUPADO_ALIADO("Casa ocupada por peça aliada! Você não pode capturar suas próprias peças."),
		CAMINHO_BLOQUEADO("Caminho bloqueado! Há uma peça bloqueando o avanço do peão."),
		PEAO_BLOQUEADO_FRENTE("Peão bloqueado! Há uma peça diretamente na frente"),
		CAPTURA_INVALIDA("Captura inválida! Você não pode capturar neste tabuleiro"),
		INPUT_INVALIDO("Formato de entrada inválido! Use o formato: linha,coluna (Exemplo: 6,0 ou 6 0)"),
		OPERACAO_CANCELADA("Operação cancelada pelo usuário.");

		private final String mensagem;

		TipoErro(String mensagem) {
			this.mensagem = mensagem;
		}

		public String getMensagem() {
			return mensagem;
		}
	}
}