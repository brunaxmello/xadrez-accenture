package xadrez.peca;

import xadrez.tabuleiro.Tabuleiro;
import xadrez.exceptions.XadrezException;

public class Peao {


    private int linha;
    private int coluna;
    private final Cor cor;
    private boolean primeiroMovimento;

    public Peao(int linha, int coluna, Cor cor) {
        this.linha = linha;
        this.coluna = coluna;
        this.cor = cor;
        this.primeiroMovimento = true;
    }

    // Valida o movimento do peão e lança exceção se inválido
    public void validarMovimento(int linhaDestino, int colunaDestino, Tabuleiro tabuleiro) {
        int deltaLinha = linhaDestino - linha;
        int deltaColuna = colunaDestino - coluna;

        // Define a direção do peão: Brancos avançam +1, Pretos -1
        int direcao = (cor == Cor.BRANCO) ? 1 : -1;

        // Movimento deve ser sempre para frente
        if (deltaLinha * direcao <= 0) {
            throw new XadrezException(XadrezException.TipoErro.MOVIMENTO_INVALIDO);
        }

        // Movimento reto
        if (deltaColuna == 0) {
            validarMovimentoFrente(linhaDestino, Math.abs(deltaLinha), direcao, tabuleiro);
            return;
        }

        // Captura diagonal (1 casa de diferença na coluna)
        if (Math.abs(deltaColuna) == 1) {
            validarCaptura(linhaDestino, colunaDestino, Math.abs(deltaLinha), tabuleiro);
            return;
        }

        // Caso não seja nem movimento reto nem captura diagonal
        throw new XadrezException(XadrezException.TipoErro.MOVIMENTO_INVALIDO);
    }

    // Valida avanço reto de 1 ou 2 casas
    private void validarMovimentoFrente(int linhaDestino, int distancia, int direcao, Tabuleiro tabuleiro) {

        // Verifica se o destino está bloqueado
        if (tabuleiro.possuiPeca(linhaDestino, coluna)) {
            throw new XadrezException(XadrezException.TipoErro.PEAO_BLOQUEADO_FRENTE);
        }

        if (distancia == 1) {
            return; // Movimento de 1 casa válido
        }

        if (distancia == 2) {
            // Movimento de 2 casas permitido somente no primeiro movimento
            if (!primeiroMovimento) {
                throw new XadrezException(XadrezException.TipoErro.PEAO_JA_MOVIMENTADO);
            }

            // Verifica se a casa intermediária está livre
            int lIntermediaria = linha + direcao;
            if (tabuleiro.possuiPeca(lIntermediaria, coluna)) {
                throw new XadrezException(XadrezException.TipoErro.CAMINHO_BLOQUEADO);
            }
            return;
        }

        // Mais de 2 casas não permitido
        throw new XadrezException(XadrezException.TipoErro.MOVIMENTO_INVALIDO);
    }

    // Valida captura diagonal( não permitida) do peão
    private void validarCaptura(int linhaDestino, int colunaDestino, int distancia, Tabuleiro tabuleiro) {

        // Captura deve ser exatamente 1 casa na diagonal
        if (distancia != 1) {
            throw new XadrezException(XadrezException.TipoErro.CAPTURA_INVALIDA);
        }

        // Deve haver peça adversária no destino
        if (!tabuleiro.possuiPeca(linhaDestino, colunaDestino)) {
            throw new XadrezException(XadrezException.TipoErro.CAPTURA_INVALIDA);
        }

        Peao pecaDestino = tabuleiro.obterPeca(linhaDestino, colunaDestino);

        // Não é permitido capturar aliado
        if (pecaDestino.cor == this.cor) {
            throw new XadrezException(XadrezException.TipoErro.DESTINO_OCUPADO_ALIADO);
        }
    }

    // Atualiza posição do peão e marca como já movido
    public void mover(int linhaDestino, int colunaDestino) {
        this.linha = linhaDestino;
        this.coluna = colunaDestino;
        this.primeiroMovimento = false;
    }


    public String getRepresentacao() {
        return (cor == Cor.BRANCO) ? "♙" : "♟";
    }


    public int getLinha() {
        return linha;
    }


    public Cor getCor() {
        return cor;
    }


    public enum Cor {
        BRANCO("Branco"), PRETO("Preto");

        private final String nome;

        Cor(String nome) {
            this.nome = nome;
        }
    }
}
