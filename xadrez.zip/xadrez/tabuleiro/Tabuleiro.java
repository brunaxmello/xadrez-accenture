package xadrez.tabuleiro;

import xadrez.exceptions.XadrezException;
import xadrez.peca.Peao;

public class Tabuleiro {

    private final Peao[][] matriz;


    public Tabuleiro() {
        this.matriz = new Peao[8][8];
    }

    // Retorna a peça localizada em uma posição específica
    public Peao obterPeca(int linha, int coluna) {
        validarPosicao(linha, coluna);
        return matriz[linha][coluna];
    }

    // Verifica se há uma peça em determinada posição
    public boolean possuiPeca(int linha, int coluna) {
        validarPosicao(linha, coluna);
        return matriz[linha][coluna] != null;
    }

    // Coloca uma peça em uma posição específica do tabuleiro
    public void colocarPeca(Peao peca, int linha, int coluna) {
        validarPosicao(linha, coluna);

        // Impede sobrescrever uma peça já existente na posição
        if (matriz[linha][coluna] != null) {
            throw new XadrezException(XadrezException.TipoErro.DESTINO_OCUPADO_ALIADO);
        }

        matriz[linha][coluna] = peca;
    }

    // Remove e retorna a peça de uma posição específica
    public Peao removerPeca(int linha, int coluna) {
        validarPosicao(linha, coluna);
        Peao removida = matriz[linha][coluna];
        matriz[linha][coluna] = null;
        return removida;
    }

    // Move uma peça de uma posição de origem para uma posição de destino
    public void moverPeca(int linhaOrigem, int colunaOrigem, int linhaDestino, int colunaDestino) {
        validarPosicao(linhaOrigem, colunaOrigem);
        validarPosicao(linhaDestino, colunaDestino);

        Peao pecaOrigem = obterPeca(linhaOrigem, colunaOrigem);

        // Verifica se há peça na posição de origem
        if (pecaOrigem == null) {
            throw new XadrezException(XadrezException.TipoErro.POSICAO_VAZIA);
        }

        // Valida se o movimento é permitido para o Peão
        pecaOrigem.validarMovimento(linhaDestino, colunaDestino, this);

        // Executa a movimentação na matriz do tabuleiro
        matriz[linhaDestino][colunaDestino] = pecaOrigem;
        matriz[linhaOrigem][colunaOrigem] = null;

        // Atualiza a posição interna da peça
        pecaOrigem.mover(linhaDestino, colunaDestino);
    }

    // Valida se a posição está dentro dos limites do tabuleiro
    private void validarPosicao(int linha, int coluna) {
        if (linha < 0 || linha > 7 || coluna < 0 || coluna > 7) {
            throw new XadrezException(XadrezException.TipoErro.POSICAO_INVALIDA);
        }
    }

    // Retorna a matriz interna do tabuleiro
    public Peao[][] getMatriz() {
        return matriz;
    }
}
